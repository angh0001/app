package com.example.archi.merriamwebsterdictionary;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class DefinationText extends AppCompatActivity {


    //private TextView defView;
    private FloatingActionButton deleteButton;
    ArrayList<String> definations=new ArrayList<String>();
    ArrayAdapter<String> ad;
    ListView listView;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delete);

        deleteButton= (FloatingActionButton) findViewById(R.id.deleteButton);//Initilize Floating Button
        ad=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,definations);
        listView=(ListView)findViewById(R.id.definationList) ;


        Intent intent=getIntent();//Get intent

    Bundle bundle=intent.getExtras();
    long itemID=bundle.getLong("id");//Get value from Key id
    int position=bundle.getInt("position");//Get value from Key position
    String defination=bundle.getString("def");//Get value from Key def



    String[] str=defination.split(":");
        int i=0;
    while(i<(str.length-1)) {
        i++;
        definations.add(str[i]);

    }
    listView.setAdapter(ad);

   //Different approach for text view

//    StringBuffer sb=new StringBuffer(index+"."+str[1]);
//
//    String newString;
//    for(int i=2;i<str.length;i++) {
//
////        newString=str[i];
////        sb.append(newString+"\n\n"+index+".");
//index++;
//        newString="\n\n"+index+"."+str[i];
//
//        sb.append(newString);
//    }
//while(!sb.toString().equals("")){
//
//}

//defView.setText(sb.toString());


    deleteButton.setOnClickListener(d->{

    Intent backToActivity=new Intent();
    backToActivity.putExtra("id",bundle.getLong("id"));//set value for Key id
        backToActivity.putExtra("position",bundle.getInt("position"));
    setResult(Activity.RESULT_OK,backToActivity);//send data back to SavedDefination in onActivityResult()
    finish();//Go to back Activity
});
    }
}