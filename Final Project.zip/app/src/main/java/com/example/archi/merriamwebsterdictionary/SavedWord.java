package com.example.archi.merriamwebsterdictionary;

import java.util.ArrayList;

public class SavedWord {
    public String word;
    public String defination;

    public long id;


    /**Constructor:*/
    public SavedWord(long id, String word, String defination) {
        this.id = id;
        this.word = word;
        this.defination = defination;
    }


    public SavedWord(String word, String defination) {
        this.word = word;
        this.defination = defination;
    }

    public String getDefination() {
        return defination;
    }

    public void setDefination(String defination) {
        this.defination = defination;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public long getId() {

        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}